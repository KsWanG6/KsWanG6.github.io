/**
 * Home page component for the KSWang Lab website
 * Main entry point with academic-style layout and floating navigation
 */
import React, { useState } from 'react'

import Navigation from '../components/Navigation'
import Hero from '../components/Hero'
import ContentSection from '../components/ContentSection'
import Footer from '../components/Footer'

/**
 * Home
 * Holds the current section state and renders navigation, hero, content, and footer.
 */
const Home: React.FC = () => {
  const [currentSection, setCurrentSection] = useState('home')

  /**
   * Handle navigation between different sections
   */
  const handleNavigation = (section: string) => {
    setCurrentSection(section)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-gray-200">
      <Navigation onNavigate={handleNavigation} currentSection={currentSection} />

      <div className="pt-20">
        {currentSection === 'home' && <Hero onNavigate={handleNavigation} />}
        <ContentSection currentSection={currentSection} />
      </div>

      <Footer />
    </div>
  )
}

export default Home
