/**
 * Content section component with academic layout
 * Professional presentation of lab information using reusable components
 */
import React from 'react'
import SectionHeader from './SectionHeader'
import ResearchAreaCard from './cards/ResearchAreaCard'
import PersonCard from './cards/PersonCard'
import PublicationItem from './publications/PublicationItem'
import PrincipalInvestigatorCard from './people/PrincipalInvestigatorCard'
import PublicationsList, { Publication } from './publications/PublicationsList'

/** Props for ContentSection */
interface ContentSectionProps {
  /** Which section to render */
  currentSection: string
}

/**
 * ContentSection
 * Renders different sections based on the current selection.
 */
const ContentSection: React.FC<ContentSectionProps> = ({ currentSection }) => {
  /**
   * Render the section content chosen by user
   */
  const renderContent = () => {
    switch (currentSection) {
      case 'research':
        return (
          <div className="bg-white">
            <div className="container mx-auto px-4 py-12">
              <div className="max-w-5xl mx-auto">
                <SectionHeader
                  title="Research Areas"
                  subtitle="Opto-electric sensing & electromagnetic effects (SERS), nanotechnology & biotechnology, surface analysis, polymer composite & biopolymer synthesis."
                  accentGradient="from-blue-600 to-cyan-500"
                />

                {/* Research Area Grid updated to user's fields */}
                <div className="grid sm:grid-cols-2 gap-6 md:gap-8">
                  <ResearchAreaCard
                    title="Opto-electric Sensing and Electromagnetic Effects (Surface-enhanced Raman Scattering, SERS)"
                    description="SERS/EC platforms and field-enhanced spectroscopic techniques for highly sensitive biomolecule and pollutant detection."
                    image="https://pub-cdn.sider.ai/u/U0R7HR00132/web-coder/6876e736711d0815fd3ce28d/resource/222539f6-916f-46c9-a9d4-3425612d9c0b.jpg"
                    accentColor="border-blue-200"
                  />
                  <ResearchAreaCard
                    title="Nanotechnology and Biotechnology"
                    description="Design of nano-hybrids and functional nanomaterials for biomedical applications and diagnostic systems."
                    image="https://pub-cdn.sider.ai/u/U0R7HR00132/web-coder/6876e736711d0815fd3ce28d/resource/3ec2bfc7-ad31-42e8-824b-171600d5c36b.jpg"
                    accentColor="border-green-200"
                  />
                  <ResearchAreaCard
                    title="Surface Analysis"
                    description="Advanced surface engineering and characterization for reproducible sensor interfaces and functional coatings."
                    image="https://pub-cdn.sider.ai/u/U0R7HR00132/web-coder/6876e736711d0815fd3ce28d/resource/44513890-2ec2-4618-9705-8e73c257b68e.jpg"
                    accentColor="border-purple-200"
                  />
                  <ResearchAreaCard
                    title="Polymer Composite and Biopolymer Synthesis"
                    description="Synthesis of polymer composites and biopolymers for robust substrates, flexible sensors, and responsive materials."
                    image="https://pub-cdn.sider.ai/u/U0R7HR00132/web-coder/6876e736711d0815fd3ce28d/resource/505ec56a-7c04-4a0a-984e-8cd5b7a77dca.jpg"
                    accentColor="border-amber-200"
                  />
                </div>
              </div>
            </div>
          </div>
        )

      case 'people':
        return (
          <div className="bg-white">
            <div className="container mx-auto px-4 py-12">
              <div className="max-w-5xl mx-auto">
                <SectionHeader
                  title="People"
                  subtitle="Our team brings together diverse expertise across engineering and life sciences."
                  accentGradient="from-violet-600 to-fuchsia-500"
                />

                {/* Principal Investigator */}
                <div className="mb-10">
                  <h3 className="text-2xl font-semibold text-gray-800 mb-6">Principal Investigator</h3>

                  <PrincipalInvestigatorCard
                    name="Kuan-Syun Wang (王冠勛)"
                    title="Postdoctoral Fellow (2023–present)"
                    avatar="https://pub-cdn.sider.ai/u/U0R7HR00132/web-coder/6876e736711d0815fd3ce28d/resource/2e2c3ee8-40a0-4263-a4c3-20982402c685.jpg"
                    bio="Postdoctoral Fellow (2023–present)."
                    email="xian5379@me.com"
                    mobile="+886-988-862-755"
                    education="PhD (2018–2023) Inst. Polymer Science and Engineering, National Taiwan University"
                    scholarUrl="https://scholar.google.com.tw/citations?hl=zh-TW&amp;user=h_dKk_8AAAAJ&amp;view_op=list_works&amp;sortby=pubdate"
                    interests={[]}
                  />
                </div>

                {/* Postdoctoral Fellows */}
                <div className="mb-10">
                  <h3 className="text-2xl font-semibold text-gray-800 mb-6">Postdoctoral Fellows</h3>
                  <div className="grid md:grid-cols-1 gap-6">
                    <PersonCard
                      name="Kuan-Syun Wang (王冠勛)"
                      role="Postdoctoral Fellow (2023–present)"
                      avatar="https://pub-cdn.sider.ai/u/U0R7HR00132/web-coder/6876e736711d0815fd3ce28d/resource/2e2c3ee8-40a0-4263-a4c3-20982402c685.jpg"
                      education="PhD (2018–2023) Inst. Polymer Science and Engineering, National Taiwan University"
                      mobile="+886-988-862-755"
                      email="xian5379@me.com"
                      layout="row"
                    />
                  </div>
                </div>

                {/* Graduate Students */}
                <div className="mb-10">
                  <h3 className="text-2xl font-semibold text-gray-800 mb-6">Graduate Students</h3>
                  <div className="grid md:grid-cols-2 gap-6">
                    <PersonCard
                      name="Alex Thompson"
                      role="Ph.D. Student (2022-present)"
                      avatar="https://pub-cdn.sider.ai/u/U0R7HR00132/web-coder/6876e736711d0815fd3ce28d/resource/7adbe969-2d7e-490e-989a-2a43ae7b359e.jpg"
                      details="Research: Nanocarriers for targeted cancer therapy"
                      layout="row"
                    />
                    <PersonCard
                      name="Lisa Park"
                      role="M.S. Student (2023-present)"
                      avatar="https://pub-cdn.sider.ai/u/U0R7HR00132/web-coder/6876e736711d0815fd3ce28d/resource/7adbe969-2d7e-490e-989a-2a43ae7b359e.jpg"
                      details="Research: Smart hydrogels for wound healing"
                      layout="row"
                    />
                  </div>
                </div>

                {/* Undergraduate Students */}
                <div>
                  <h3 className="text-2xl font-semibold text-gray-800 mb-6">Undergraduate Students</h3>
                  <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
                    <PersonCard
                      name="Sarah Johnson"
                      role="Biomedical Engineering"
                      avatar="https://pub-cdn.sider.ai/u/U0R7HR00132/web-coder/6876e736711d0815fd3ce28d/resource/4865b7a8-7729-422d-8343-9785bb962079.jpg"
                      layout="column"
                    />
                    <PersonCard
                      name="Michael Chen"
                      role="Materials Science"
                      avatar="https://pub-cdn.sider.ai/u/U0R7HR00132/web-coder/6876e736711d0815fd3ce28d/resource/4865b7a8-7729-422d-8343-9785bb962079.jpg"
                      layout="column"
                    />
                    <PersonCard
                      name="Emma Rodriguez"
                      role="Chemical Engineering"
                      avatar="https://pub-cdn.sider.ai/u/U0R7HR00132/web-coder/6876e736711d0815fd3ce28d/resource/4865b7a8-7729-422d-8343-9785bb962079.jpg"
                      layout="column"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )

      case 'publications': {
        /**
         * Complete SCI publications list aggregated from provided documents (2014–2025).
         * Notes: Removed obvious duplicates; preserved representative/cover notes in journalMeta.
         */
        const publications: Publication[] = [
          // 2025
          {
            year: 2025,
            title:
              'Conductive polymer–reduced graphene oxide-coupled ferric oxide composite coatings for electromagnetic wave shielding',
            journalMeta: 'Progress in Organic Coatings, 200, 109078 (SCI)',
            authors:
              'Po-Tuan Chen, Yu-Chun Lu, Kuan-Syun Wang, Chi-Ming Liu, Tung-Yuan Yung, Ren-Jei Chung, Ting-Yu Liu',
          },
          {
            year: 2025,
            title:
              'Development of asphaltene-derived hierarchically activated carbon and carbon-coated Li4Ti5O12 for high-performance lithium-ion capacitors',
            journalMeta: 'Journal of Energy Storage, 119, 116325 (SCI)',
            authors:
              'Kuen-Chan Lee, Jen-Hsien Huang, Wei Kong Pang, Kuan-Syun Wang, Shih-Chieh Hsu, Huei Chu Weng, Ting-Yu Liu',
          },
          {
            year: 2025,
            title:
              'Eco-Friendly Hybrid Materials for Steel Protection Using a Water-Soluble Polyamic Acid as Chelating Agent',
            journalMeta: 'ACS Applied Polymer Materials, 7(10), 6513–6522 (SCI)',
            authors:
              'Chung-Ta Hsieh, Ying-Chi Huang, Tsung-Yu Yu, Kuan-Syun Wang, Yu-Wei Cheng, Chien-Hsin Wu, Ru-Jong Jeng',
          },

          // 2024
          {
            year: 2024,
            title:
              'Simultaneous detection of SARS-CoV-2 S1 protein by using flexible electrochemical and Raman enhancing biochip',
            journalMeta: 'Biosensors and Bioelectronics, 249, 116021 (SCI) (Representative work)',
            authors:
              'Kuan-Syun Wang, Tsai-Yu Kuan, Yun-Chu Chen, Yu-Ju Chu, Jeng-Shiung Chen, Cheng-Cheung Chen*, Ting-Yu Liu*',
          },
          {
            year: 2024,
            title:
              'Construction of hierarchical flower-like BiVO4/Bi2WO6 microspheres with enhanced electrochemical performance for supercapacitors and lithium ion batteries',
            journalMeta: 'Journal of Energy Storage, 101, 113865 (SCI)',
            authors:
              'Kuen-Chan Lee, Jen-Hsien Huang, Wei Kong Pang, Kuan-Syun Wang, Shih-Chieh Hsu, Huei Chu Weng, Ting-Yu Liu',
          },
          {
            year: 2024,
            title:
              'Functionalization of Graphene Nanosheets-3D Printing Resins for Improvement of Mechanical Properties and Thermal Conductivity',
            journalMeta: 'ACS Applied Polymer Materials, 6, 3222 (SCI)',
            authors:
              'Kuan-Syun Wang, Yao-Sheng Zhang, Wei-Han Lo, Chin-Ching Lin, Cheng-Chen Chen, Jen-Hung Fang, Ting-Yu Liu',
          },
          {
            year: 2024,
            title:
              'Electrochemically deposited Au nano-island on laser-scribed graphene substrates as EC-SERS biochips for uremic toxins detection',
            journalMeta:
              'Journal of the Taiwan Institute of Chemical Engineers, 97, 112639 (SCI) (Co-first author)',
            authors:
              'Ruey-Shin Juang, Kuan-Syun Wang, Yun-Chu Chen, Yu-Ju Chu, Ying-Jun Lin, Shou-Hsuan Liu*, Ding-Zheng Lin*, Ting-Yu Liu*',
          },
          {
            year: 2024,
            title:
              'Crystal structure-controlled synthesis of NiMoO4/NiO hierarchical microspheres for high-performance supercapacitors and photocatalysts',
            journalMeta: 'Journal of Energy Storage, 97, 112639 (SCI)',
            authors:
              'Kuen-Chan Lee, Jen-Hsien Huang, Yen-Ju Wu, Kuan-Syun Wang, Er-Chieh Cho*, Shih-Chieh Hsu*, Ting-Yu Liu*',
          },
          {
            year: 2024,
            title:
              'Electrochemical polymerization of PEDOT:PSS with graphene oxide and silver nanoparticles for antibacterial coating and SERS detection',
            journalMeta: 'Surface & Coatings Technology, 485, 130889 (SCI)',
            authors:
              'Kuan-Syun Wang, Hsiang-Ting Lan, Chun-Hao Wu, Yun-Chu Chen, Ying-Jun Lin, Ting-Jia Sung, Jeng-Shiung Chen, Yu-Wei Cheng*, Ren-Jei Chung*, Ting-Yu Liu*',
          },
          {
            year: 2024,
            title:
              'Thiol-functionalized mesoporous silica-embedded AuNPs with highly sensitive substrates for surface-enhanced Raman scattering detection',
            journalMeta: 'Surface & Coatings Technology, 483, 130814 (SCI)',
            authors:
              'Kuan-Syun Wang, Hsuan-Ting Lin, Yu-Jie Wen, Li-Ying Huang, Ming-Chien Yang, Ting-Yu Liu*',
          },
          {
            year: 2024,
            title:
              'Preparation of Amphiphilic Ag-Polyethylenimine Dendritic Polymer Nanocapsules for Surface-Enhanced Raman Scattering Detection',
            journalMeta: 'ACS Applied Polymer Materials, 6, 3222 (SCI) [Cover Image]',
            authors:
              'Qi-Yang Xu, Gong-De Lin, Kuan-Syun Wang, Ying-Chi Huang, Yu-Xuan Huang, Chen-Yang Lin, Chien-Hsin Wu*, Ru-Jong Jeng*, Ting-Yu Liu*',
          },
          {
            year: 2024,
            title:
              'Electric field-stimulated Raman scattering enhancing biochips fabricated by Au nano-islands deposited on laser-scribed 3D graphene for uremic toxins detection',
            journalMeta:
              'Journal of the Taiwan Institute of Chemical Engineers, 154, 105115 (SCI)',
            authors:
              'Ruey-Shin Juang, Kuan-Syun Wang, Tsai-Yu Kuan, Yu-Ju Chu, Ru-Jong Jeng, Andri Hardiansyah*, Shou-Hsuan Liu*, Ting-Yu Liu*',
          },

          // 2023
          {
            year: 2023,
            title:
              'Synthesis of dendritic urethane acrylates for fabricating a robust honeycomb-like structure acting for SERS detection',
            journalMeta: 'Progress in Organic Coatings, 184, 107840 (SCI)',
            authors:
              'Kuan-Syun Wang, Yu-Wei Cheng, Han-Yu Lin, Min-Hao Chen, Shih-Chieh Yeh, Ying-Chi Huang, Chien-Hsin Wu*, Ru-Jong Jeng*, Ting-Yu Liu*',
          },
          {
            year: 2023,
            title:
              'Reproducible SERS substrates manipulated by interparticle spacing and particle diameter of gold nano-island array using in-situ thermal evaporation',
            journalMeta: 'Spectrochimica Acta Part A, 303, 123190 (SCI)',
            authors:
              'Ming-Chien Yang, Ting-Yin Chien, Yu-Wei Cheng*, Chien-Kuo Hsieh, Wei-Lin Syu, Kuan-Syun Wang, Yun-Chu Chen, Jeng-Shiung Chen, Cheng-Cheung Chen*, Ting-Yu Liu*',
          },
          {
            year: 2023,
            title:
              'Surface Modification of Li3VO4 with PEDOT:PSS Conductive Polymer as an Anode Material for Li-Ion Capacitors',
            journalMeta: 'Polymers, 15, 2502 (SCI)',
            authors:
              'Shih-Chieh Hsu, Kuan-Syun Wang, Yan-Ting Lin, Jen-Hsien Huang, Nian-Jheng Wu, Jia-Lin Kang*, Huei-Chu Weng*, Ting-Yu Liu*',
          },
          {
            year: 2023,
            title:
              'Thiol-End-Group Dendrons Decorated with Gold Nanoparticles Immobilized on Amino-Functionalized Graphene Oxide for SERS Detection',
            journalMeta: 'ACS Applied Polymer Materials, 5, 1765 (SCI) [Cover Image]',
            authors:
              'Kuan-Syun Wang, Chien-Hsin Wu, Chi-Hsien Huang, Yu-Wei Cheng*, Ru-Jong Jeng*, Ting-Yu Liu*',
          },
          {
            year: 2023,
            title:
              'Flexible PDMS-Based SERS Substrates Replicated from Beetle Wings for Water Pollutant Detection',
            journalMeta: 'Polymers, 15, 191 (SCI)',
            authors:
              'Chen-Hsin Lu, Ming-Ren Cheng, Sheng Chen, Wei-Lin Syu, Ming-Yen Chien, Kuan-Syun Wang, Jeng-Shiung Chen, Po-Han Lee*, Ting-Yu Liu*',
          },

          // 2022
          {
            year: 2022,
            title:
              'Reduced Graphene Oxide Nanosheets Decorated with Core-Shell of Fe3O4-Au Nanoparticles for Rapid SERS Detection and Hyperthermia Treatment of Bacteria',
            journalMeta: 'Spectrochimica Acta Part A, 281, 121578 (SCI)',
            authors:
              'Ming-Chien Yang, Andri Hardiansyah, Yu-Wei Cheng*, Hung-Liang Liao, Kuan-Syun Wang, Ahmad Randy, Christian Harito, Jeng-Shiung Chen, Ru-Jong Jeng*, Ting-Yu Liu*',
          },
          {
            year: 2022,
            title:
              'Intelligent and thermo-responsive Au-pluronic F127 nanocapsules for Raman-enhancing detection of biomolecules',
            journalMeta: 'Spectrochimica Acta Part A, 279, 121475 (SCI)',
            authors:
              'Ruey-Shin Juang, Kuan-Syun Wang, Yu-Wei Cheng, Wei-En Wu, Yu-Hsuan Lin, Ru-Jong Jeng, Li-Ying Huang, Ming-Chien Yang*, Shou-Hsuan Liu*, Ting-Yu Liu*',
          },
          {
            year: 2022,
            title:
              'Fabrication of in situ magnetic capturing and Raman enhancing nanoplatelets for detection of bacteria and biomolecules',
            journalMeta: 'Colloids and Surfaces A, 648, 129189 (SCI)',
            authors:
              'Ruey-Shin Juang, Wei-Ting Chen, Yu-Wei Cheng*, Kuan-Syun Wang, Ru-Jong Jeng, Zi-Ling Zeng, Shou-Hsuan Liu*, Ting-Yu Liu*',
          },
          {
            year: 2022,
            title:
              'Novel Strategy for Flexible and Super-Hydrophobic SERS Substrate Fabricated by Deposited Gold Nanoislands on Organic Semiconductor Nanostructures for Bio-Detection',
            journalMeta: 'Surface & Coatings Technology, 435, 128251 (SCI)',
            authors:
              'Kuan-Syun Wang, Zi-Ling Tseng, Chih-Yi Liu, Tsai-Yu Kuan, Ru-Jong Jeng, Ming-Chien Yang*, Yuh-Lin Wang*, Ting-Yu Liu*',
          },
          {
            year: 2022,
            title:
              'Thermoresponsive SERS Nanocapsules Constructed by Linear-Dendritic Poly(Urea/Malonamide) for Tunable Biomolecule Detection',
            journalMeta: 'ACS Applied Polymer Materials, 4, 240 (SCI) [Cover Image]',
            authors:
              'Yu-Wei Cheng, Wen-Hao Chuang, Kuan-Syun Wang, Wen-Chi Tseng, Wen-Yen Chiu, Chien-Hsin Wu*, Ting-Yu Liu*, Ru-Jong Jeng*',
          },

          // 2020
          {
            year: 2020,
            title:
              'Silver nanoparticles embedded on mesoporous-silica modified reduced graphene-oxide nanosheets for SERS detection of uremic toxins and parathyroid hormone',
            journalMeta: 'Applied Surface Science, 521, 146372 (SCI)',
            authors:
              'Ruey-Shin Juang, Yu-Wei Cheng*, Wan-Tzu Chen, Kuan-Syun Wang, Chun-Chieh Fu, Shou-Hsuan Liu, Ru-Jong Jeng, Cheng-Cheung Chen, Ming-Chien Yang*, Ting-Yu Liu*',
          },

          // 2019
          {
            year: 2019,
            title:
              'Synthesis and properties of cyclopentyl cardo-type polyimides based on dicyclopentadiene',
            journalMeta: 'Polymers, 11(12), 2029 (SCI)',
            authors:
              'Shih-Chieh Yeh, Jen-Yu Lee, Chung-Ta Hsieh, Ya-Chin Huang, Kuan-Syun Wang, Chien-Hsin Wu*, Chien-Chieh Hu*, Shu-Chen Chiang, Ru-Jong Jeng*',
          },
          {
            year: 2019,
            title:
              'Floating SERS substrates of silver nanoparticles-graphene based nanosheets for rapid detection of biomolecules and clinical uremic toxins',
            journalMeta:
              'Colloids and Surfaces A, 576, 36 (SCI) (Co-first author) (Cover Image)',
            authors:
              'Ruey-Shin Juang, Kuan-Syun Wang, Yu-Wei Cheng, Chun-Chieh Fu, Wan-Tzu Chen, Chi-Ming Liu, Chu-Chun Chien, Ru-Jong Jeng, Cheng-Cheung Chen, Ting-Yu Liu*',
          },

          // 2018
          {
            year: 2018,
            title:
              'Highly sensitive and reproducible SERS substrates of bilayer Au and Ag nano-island arrays by thermal evaporation deposition',
            journalMeta: 'Surface & Coatings Technology, 350, 823–830 (SCI)',
            authors:
              'Wei-Lin Syu, Yu-Hsuan Lin, Abhyuday Paliwal, Kuan-Syun Wang, Ting-Yu Liu*',
          },

          // 2017
          {
            year: 2017,
            title:
              'SERS Detection of Biomolecules by Highly Sensitive and Reproducible Raman Enhancing Nanoparticle Array',
            journalMeta: 'Nanoscale Research Letters, 12, 344 (SCI)',
            authors:
              'Tzu-Yi Chan, Ting-Yu Liu*, Kuan-Syun Wang, Kun-Tong Tsai, Zhi-Xin Chen, Yu-Chi Chang, Yi-Qun Tseng, Chih-Hao Wang, Juen-Kai Wang, Yuh-Lin Wang',
          },
          {
            year: 2017,
            title:
              'Magnetic and Thermal-Sensitive Poly(N-isopropylacrylamide)-based Microgels for Magnetically Triggered Controlled Release',
            journalMeta: 'JoVE - Journal of Visualized Experiments, 55648 (SCI)',
            authors:
              'Chih-Yu Kuo, Ting-Yu Liu*, Kuan-Syun Wang, Andri Hardiansyah, Yen-Ting Lin, Hsueh-Yung Chen, Wen-Yen Chiu',
          },

          // 2016
          {
            year: 2016,
            title:
              'Synthesis of PtNi Alloy Nanoparticles on Graphene-Based Polymer Nanohybrids for Electrocatalytic Oxidation of Methanol',
            journalMeta: 'Catalysts, 6, 201 (SCI)',
            authors:
              'Tung-Yuan Yung, Ting-Yu Liu*, Kuan-Syun Wang, Che-Chun Liu, Shih-Hsuan Wang, Po-Tuan Chen, Chi-Yang Chao',
          },
          {
            year: 2016,
            title:
              'The Polar Solvent Effect of Transparent Conductive Films Composed of Graphene/PEDOT:PSS Nanohybrids',
            journalMeta: 'Surface & Coatings Technology, 303, 244–249 (SCI)',
            authors:
              'Che-Chun Liu, Ting-Yu Liu*, Kuan-Syun Wang, Hui-Ming Tsou, Shih-Hsuan Wang, Jung-San Chen',
          },

          // 2015
          {
            year: 2015,
            title:
              'Influence of Magnetic Nanoparticle Arrangement in the Ferrogels for Tunable Biomolecules Diffusion',
            journalMeta: 'RSC Advances, 5, 90098 (SCI)',
            authors: 'Ting-Yu Liu*, Tzu-Yi Chan, Kuan-Syun Wang, Hui-Ming Tsou',
          },
          {
            year: 2015,
            title:
              'Fabrication of Gold Nanoparticles/Graphene-PDDA Nanohybrids for Bio-Detection by SERS Nanotechnology',
            journalMeta: 'Nanoscale Research Letters, 10, 397 (SCI)',
            authors:
              'Andreas H.H. Mevold, Weu-Wu Hsu, Andri Hardiansyah, Li-Ying Huang, Ming-Chien Yang*, Ting-Yu Liu*, Tzu-Yi Chan, Kuan-Syun Wang, Yu-An Su, Ru-Jong Jeng, Juen-Kai Wang, Yuh-Lin Wang',
          },
          {
            year: 2015,
            title:
              'Characterization of Au and Bimetallic PtAu Nanoparticles on PDDA-Graphene Sheets as Electrocatalysts for Formic Acid Oxidation',
            journalMeta: 'Nanoscale Research Letters, 10, 365 (SCI)',
            authors:
              'Tung-Yuan Yung, Ting-Yu Liu*, Li-Ying Huang, Kuan-Syun Wang, Huei-Ming Tzou, Po-Tuan Chen, Chi-Yang Chao, Ling-Kang Liu*',
          },
          {
            year: 2015,
            title:
              'Core-Shell Structure of Gold Nanoparticles with Inositol Hexaphosphate Nanohybrids for Label-Free and Rapid Detection by SERS Nanotechnology',
            journalMeta:
              'Journal of Nanomaterials, Article ID 857154 (SCI)',
            authors:
              'Andreas H.H. Mevold, Jin-Yuan Liu, Li-Ying Huang, Hung-Liang Liao, Ming-Chien Yang*, Tzu-Yi Chan, Kuan-Syun Wang, Juen-Kai Wang, Yuh-Lin Wang, Ting-Yu Liu*',
          },

          // 2014
          {
            year: 2014,
            title:
              'Synthesis and Characterizations of Ni-NiO Nanoparticles on PDDA-Modified Graphene for Oxygen Reduction Reaction',
            journalMeta: 'Nanoscale Research Letters, 9, 444 (SCI)',
            authors:
              'Tung-Yuan Yung, Li-Ying Huang, Tzu-Yi Chan, Kuan-Syun Wang, Ting-Yu Liu*, Po-Tuan Chen, Chi-Yang Chao, Ling-Kang Liu*',
          },
        ]

        return (
          <div className="bg-white">
            <div className="container mx-auto px-4 py-12">
              <div className="max-w-4xl mx-auto">
                <SectionHeader
                  title="Publications"
                  
subtitle="Complete list (sorted by year)"

                  accentGradient="from-emerald-600 to-teal-500"
                />

                {/* Publications with grouped years and Load more */}
                <PublicationsList items={publications} initialYearsToShow={5} loadMoreYears={3} />
              </div>
            </div>
          </div>
        )
      }

      case 'news':
        return (
          <div className="bg-white">
            <div className="container mx-auto px-4 py-12">
              <div className="max-w-4xl mx-auto">
                <SectionHeader
                  title="Lab News"
                  subtitle="Highlights and achievements from our lab."
                  accentGradient="from-blue-600 to-indigo-500"
                />

                <div className="space-y-8">
                  <div className="border-l-4 border-blue-600 pl-6">
                    <h3 className="text-xl font-semibold text-gray-800 mb-2">March 2024</h3>
                    <h4 className="text-lg font-medium text-gray-800 mb-2">New NSF Grant Awarded</h4>
                    <p className="text-gray-600">
                      Our lab has been awarded a $500,000 NSF grant to develop novel nanoparticle systems for targeted
                      cancer therapy. This funding will support our research over the next three years.
                    </p>
                  </div>

                  <div className="border-l-4 border-green-600 pl-6">
                    <h3 className="text-xl font-semibold text-gray-800 mb-2">February 2024</h3>
                    <h4 className="text-lg font-medium text-gray-800 mb-2">Paper Published in Nature Nanotechnology</h4>
                    <p className="text-gray-600">
                      Congratulations to Alex Thompson for his first-author paper on targeted nanoparticles published in
                      Nature Nanotechnology. This work represents a significant breakthrough in cancer drug delivery.
                    </p>
                  </div>

                  <div className="border-l-4 border-purple-600 pl-6">
                    <h3 className="text-xl font-semibold text-gray-800 mb-2">January 2024</h3>
                    <h4 className="text-lg font-medium text-gray-800 mb-2">New Lab Members</h4>
                    <p className="text-gray-600">
                      Welcome to our new lab members: Sarah Johnson and Michael Chen (undergraduate students) and Lisa
                      Park (M.S. student). We're excited to have you join our team!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )

      case 'contact':
        return (
          <div className="bg-white">
            <div className="container mx-auto px-4 py-12">
              <div className="max-w-5xl mx-auto">
                <SectionHeader
                  title="Contact"
                  subtitle="We welcome inquiries from prospective students and collaborators."
                  accentGradient="from-rose-600 to-orange-500"
                />

                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-800 mb-4">Lab Information</h3>
                    <div className="space-y-3 text-gray-600">
                      <p>
                        <strong>Principal Investigator:</strong> Dr. KS Wang
                      </p>
                      <p>
                        <strong>Department:</strong> Biomedical Engineering
                      </p>
                      <p>
                        <strong>Institution:</strong> University Research Center
                      </p>
                      <p>
                        <strong>Address:</strong> Engineering Building, Room 405
                      </p>
                      <p>
                        <strong>City:</strong> Research City, RC 12345
                      </p>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-xl font-semibold text-gray-800 mb-4">Get in Touch</h3>
                    {/* Updated: replace placeholder contact with real email/mobile and make them clickable */}
                    <div className="space-y-3 text-gray-600">
                      <p>
                        <strong>Email:</strong>{' '}
                        <a
                          href="mailto:xian5379@me.com"
                          className="text-blue-600 hover:text-blue-700"
                        >
                          xian5379@me.com
                        </a>
                      </p>
                      <p>
                        <strong>Mobile:</strong>{' '}
                        <a
                          href="tel:+886988862755"
                          className="text-blue-600 hover:text-blue-700"
                        >
                          +886-988-862-755
                        </a>
                      </p>
                      <p>
                        <strong>Office Hours:</strong> Mon–Fri 9:00 AM – 5:00 PM
                      </p>
                    </div>
                  </div>
                </div>

                <div className="mt-8 p-6 bg-gray-50 rounded-lg border border-gray-100">
                  <h3 className="text-lg font-semibold text-gray-800 mb-3">Prospective Students</h3>
                  <p className="text-gray-600">
                    We are always looking for motivated students to join our research group. If you are interested in
                    nanotechnology, biomedical engineering, or related fields, please feel free to contact Dr. Wang with
                    your CV and research interests.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )

      default:
        return null
    }
  }

  if (currentSection === 'home') {
    return null // Hero component handles home content
  }

  return renderContent()
}

export default ContentSection
