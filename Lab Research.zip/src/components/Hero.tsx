/**
 * Hero section for the Home page
 * Presents the lab's positioning, frosted-glass CTA buttons, and three key research highlights (English version).
 */
import React from 'react'
import GlassButton from '../components/GlassButton'

/** Props for the Hero section */
export interface HeroProps {
  /** Optional navigation handler to switch main sections */
  onNavigate?: (section: string) => void
}

/**
 * Hero
 * Centered headline, description, CTAs (frosted glass), and a 3-card highlight grid (English content).
 */
const Hero: React.FC<HeroProps> = ({ onNavigate }) => {
  return (
    <section className="relative bg-white">
      <div className="max-w-4xl mx-auto text-center px-4 py-12 sm:py-16">
        <h2 className="text-3xl font-bold text-gray-800 mb-6">
          Welcome to K.S. Wang Lab
        </h2>

        {/* English description based on provided materials */}
        <p className="text-lg text-gray-600 mb-8 leading-relaxed">
          We focus on opto-electric sensing and electromagnetic effects (SERS), nanotechnology and biotechnology,
          surface analysis, and polymer composites and biopolymer synthesis. Current interests include EC–SERS
          biochips for detecting biomolecules and environmental pollutants (e.g., uremic toxins, SARS‑CoV‑2 S1),
          dendritic polymer–induced self-assembly, nanohybrids of two-dimensional materials (graphene, rGO, carbon
          quantum dots), and solid polymer electrolytes.
        </p>

        {/* Frosted-glass CTAs */}
        <div className="flex items-center justify-center gap-3 sm:gap-4 mb-10">
          <GlassButton
            tone="primary"
            aria-label="Explore our research areas"
            onClick={() => onNavigate?.('research')}
          >
            Research Areas
          </GlassButton>

          <GlassButton
            tone="secondary"
            aria-label="Contact our lab"
            onClick={() => onNavigate?.('contact')}
          >
            Contact Us
          </GlassButton>
        </div>

        {/* Highlight cards */}
        <div className="grid md:grid-cols-3 gap-8 mt-6">
          {/* Card 1: SERS & EC Detection */}
          <div className="text-center">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-2xl mb-4 shadow-sm">
              <img
                src="https://pub-cdn.sider.ai/u/U0R7HR00132/web-coder/6876e736711d0815fd3ce28d/resource/24000bfd-183f-48c0-a14e-222864c5a12c.jpg"
                alt="SERS and electrochemical detection"
                className="w-full h-32 object-cover rounded-xl"
              />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">SERS and Electrochemical Detection</h3>
            <p className="text-gray-600">
              Highly sensitive detection of biomolecules and environmental pollutants (e.g., uremic toxins, SARS‑CoV‑2 S1)
            </p>
          </div>

          {/* Card 2: Nanohybrids & 2D Materials */}
          <div className="text-center">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-2xl mb-4 shadow-sm">
              <img
                src="https://pub-cdn.sider.ai/u/U0R7HR00132/web-coder/6876e736711d0815fd3ce28d/resource/e8f12e04-d04a-4afc-929e-43c3a5694e92.jpg"
                alt="Nanohybrids and two-dimensional materials"
                className="w-full h-32 object-cover rounded-xl"
              />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Nanohybrids and Two-Dimensional Materials</h3>
            <p className="text-gray-600">
              Functionalization and applications of graphene/rGO, Au/Ag nano-islands, and magnetic nanoparticles
            </p>
          </div>

          {/* Card 3: Polymers & Biomedical Materials */}
          <div className="text-center">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-2xl mb-4 shadow-sm">
              <img
                src="https://pub-cdn.sider.ai/u/U0R7HR00132/web-coder/6876e736711d0815fd3ce28d/resource/75164b7e-7e76-433a-b63a-6cfe6de0c704.jpg"
                alt="Polymers and biomedical materials"
                className="w-full h-32 object-cover rounded-xl"
              />
            </div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">Polymers and Biomedical Materials</h3>
            <p className="text-gray-600">
              Synthesis and processing of dendritic polymers, self-assembled nanocapsules, and flexible/superhydrophobic substrates
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Hero
