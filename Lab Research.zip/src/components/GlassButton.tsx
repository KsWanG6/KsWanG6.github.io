/**
 * GlassButton
 * A reusable frosted-glass CTA button built on top of shadcn Button (variant="outline").
 * Ensures bg-transparent and consistent glass effects for hover/focus/active states.
 */

import React from 'react'
import { Button } from './ui/button'

/**
 * Props for GlassButton
 * - tone: visual intensity preset for slight differentiation (primary/secondary)
 */
export interface GlassButtonProps
  extends Omit<React.ComponentProps<typeof Button>, 'variant'> {
  /** Visual tone (primary: stronger contrast; secondary: slightly softer) */
  tone?: 'primary' | 'secondary'
}

/**
 * GlassButton component
 * Renders a frosted glass CTA with backdrop blur and light gradient sheen.
 */
const GlassButton: React.FC<GlassButtonProps> = ({
  className = '',
  tone = 'primary',
  children,
  ...rest
}) => {
  /**
   * Compute tone-specific styles
   * - Both tones keep outline + transparent background for glass feel
   */
  const toneClasses =
    tone === 'primary'
      ? [
          'border-white/40',
          'shadow-md',
          'hover:shadow-lg',
          'focus-visible:ring-cyan-400/60',
        ].join(' ')
      : [
          'border-white/30',
          'shadow',
          'hover:shadow-md',
          'focus-visible:ring-cyan-400/40',
        ].join(' ')

  /**
   * Base frosted glass styling
   * - Transparent background + backdrop blur/saturate
   * - Subtle gradient sheen via before: pseudo element
   * - Good contrast in dark mode
   */
  const baseClasses = [
    // required by rule for shadcn outline button
    'bg-transparent',
    // size & typography
    'h-11 sm:h-12 px-5 sm:px-7 text-[15px] sm:text-base font-semibold',
    // glass effect
    'backdrop-blur-md backdrop-saturate-150',
    'relative overflow-hidden',
    // gradient sheen
    'before:absolute before:inset-0 before:rounded-[inherit]',
    'before:bg-gradient-to-br before:from-white/40 before:to-white/10',
    'before:opacity-0 hover:before:opacity-100 before:transition-opacity',
    // borders & text
    'border text-gray-900',
    'dark:text-white dark:border-white/20',
    // focus ring
    'focus-visible:ring-2',
    // smooth transitions
    'transition-all',
  ].join(' ')

  return (
    <Button
      variant="outline"
      className={`${baseClasses} ${toneClasses} ${className}`}
      data-glass="true"
      {...rest}
    >
      {children}
    </Button>
  )
}

export default GlassButton
