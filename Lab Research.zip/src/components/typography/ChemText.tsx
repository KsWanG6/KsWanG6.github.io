/**
 * ChemText component
 * Renders a text string and formats known chemical formulas by turning trailing digits into subscripts.
 */
import React from 'react'

/** Props for ChemText */
export interface ChemTextProps {
  /** The raw text that may contain chemical formulas (e.g., Li4Ti5O12, BiVO4, Fe3O4) */
  text: string
  /** Optional className to style the wrapper span */
  className?: string
}

/**
 * renderWithSubscripts
 * Convert digits in matched chemical tokens to <sub>digits</sub>.
 */
function renderWithSubscripts(token: string): React.ReactNode {
  const parts: React.ReactNode[] = []
  let buffer = ''
  // Simple logic: iterate characters and wrap digits with sub
  for (let i = 0; i < token.length; i++) {
    const ch = token[i]
    if (/\d/.test(ch)) {
      // flush buffer before number
      if (buffer) {
        parts.push(buffer)
        buffer = ''
      }
      parts.push(<sub key={`sub-${i}`}>{ch}</sub>)
    } else {
      buffer += ch
    }
  }
  if (buffer) parts.push(buffer)
  return <>{parts}</>
}

/**
 * ChemText
 * Split text by known chemical tokens, and render matched tokens with digit subscripts.
 * Note: Keep the token list concise to avoid false positives (e.g., "F127" in Pluronic F127).
 */
const ChemText: React.FC<ChemTextProps> = ({ text, className }) => {
  // Known chemical tokens to subscript digits within.
  // Keep specific to avoid matching non-chemical product names like F127.
  const TOKENS = ['Li4Ti5O12', 'BiVO4', 'Bi2WO6', 'Li3VO4', 'NiMoO4', 'NiO', 'Fe3O4']

  // Build a regex that matches any of the tokens exactly; use capturing group to retain separators.
  const regex = new RegExp(`(${TOKENS.join('|')})`, 'g')

  // Split text by tokens and render.
  const segments = text.split(regex)

  return (
    <span className={className}>
      {segments.map((seg, idx) => {
        if (TOKENS.includes(seg)) {
          return <React.Fragment key={`chem-${idx}`}>{renderWithSubscripts(seg)}</React.Fragment>
        }
        return <React.Fragment key={`txt-${idx}`}>{seg}</React.Fragment>
      })}
    </span>
  )
}

export default ChemText
