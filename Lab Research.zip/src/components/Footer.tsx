/**
 * Footer component
 * Provides site footer with concise lab info and contact line.
 */
import React from 'react'

/**
 * Footer
 * A minimal, readable footer to close the page with credibility.
 */
const Footer: React.FC = () => {
  return (
    <footer className="mt-16">
      <div className="border-t border-gray-200" />
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-gray-600">
          <div className="text-center md:text-left">
            <p className="font-semibold text-gray-800">KSWang Lab</p>
            <p>Department of Biomedical Engineering · University Research Center</p>
          </div>
          
<p className="text-center md:text-right">
  Email: <a href="mailto:xian5379@me.com" className="text-blue-600 hover:text-blue-700">xian5379@me.com</a> · Mobile: <a href="tel:+886988862755" className="text-blue-600 hover:text-blue-700">+886-988-862-755</a>
</p>

        </div>
      </div>
    </footer>
  )
}

export default Footer
