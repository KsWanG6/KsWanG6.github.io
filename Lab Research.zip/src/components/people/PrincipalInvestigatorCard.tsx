/**
 * PrincipalInvestigatorCard component
 * A reusable, responsive card for displaying PI profile with bio, contacts, interests and actions.
 */
import React from 'react'
import { Mail, MapPin, FileText, GraduationCap, Phone, BookOpen } from 'lucide-react'
import { Button } from '../ui/button'

/** Props for PrincipalInvestigatorCard */
export interface PrincipalInvestigatorCardProps {
  /** PI name */
  name: string
  /** Academic/professional title */
  title: string
  /** Avatar image url */
  avatar: string
  /** Short bio (if not provided, component will hide bio area) */
  bio?: string
  /** Email address (will be converted to mailto link) */
  email?: string
  /** Mobile phone number (will be converted to tel link) */
  mobile?: string
  /** Office location text (converted to a Google Maps query link) */
  office?: string
  /** Education text (e.g., PhD ... ) */
  education?: string
  /** Optional Google Scholar link */
  scholarUrl?: string
  /** Optional CV link */
  cvUrl?: string
  /** Optional research interests to show as badges */
  interests?: string[]
}

/**
 * PrincipalInvestigatorCard
 * Provides a polished profile card for the PI with clear actions and readable layout.
 */
const PrincipalInvestigatorCard: React.FC<PrincipalInvestigatorCardProps> = ({
  name,
  title,
  avatar,
  bio,
  email,
  mobile,
  office,
  education,
  scholarUrl,
  cvUrl,
  interests = [],
}) => {
  /** Build mailto link for email */
  const mailto = email ? `mailto:${email}` : undefined
  /** Build tel link for phone */
  const tel = mobile ? `tel:${mobile.replaceAll(' ', '')}` : undefined
  /** Build a Google Maps query link from office text */
  const officeMap = office ? `https://maps.google.com/?q=${encodeURIComponent(office)}` : undefined

  return (
    <div className="rounded-xl bg-white border border-gray-100 p-6 shadow-sm hover:shadow-md transition-shadow">
      {/* Accent bar */}
      <div className="h-1 w-16 rounded-full bg-gradient-to-r from-blue-600 to-cyan-500 mb-5" aria-hidden="true" />
      <div className="flex flex-col sm:flex-row items-start gap-6">
        <img
          src={avatar}
          alt={name}
          className="w-24 h-24 sm:w-28 sm:h-28 rounded-lg object-cover flex-shrink-0"
        />
        <div className="flex-1">
          <h4 className="text-2xl font-semibold text-gray-900 mb-1">{name}</h4>
          <p className="text-gray-600 mb-3">{title}</p>

          {/* Bio */}
          {bio ? <p className="text-gray-700 leading-relaxed mb-4">{bio}</p> : null}

          {/* Interests */}
          {interests.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-4">
              {interests.map((tag) => (
                <span
                  key={tag}
                  className="inline-flex items-center gap-1 rounded-full border border-gray-200 bg-gray-50 px-2.5 py-1 text-xs text-gray-700"
                >
                  <GraduationCap className="h-3.5 w-3.5 text-blue-600" />
                  {tag}
                </span>
              ))}
            </div>
          )}

          {/* Contacts */}
          <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm mb-5">
            {email && mailto && (
              <a href={mailto} className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-700">
                <Mail className="w-4 h-4" />
                <span>{email}</span>
              </a>
            )}
            {mobile && tel && (
              <a href={tel} className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-700">
                <Phone className="w-4 h-4" />
                <span>{mobile}</span>
              </a>
            )}
            {office && officeMap && (
              <a href={officeMap} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-700">
                <MapPin className="w-4 h-4" />
                <span>{office}</span>
              </a>
            )}
          </div>

          {/* Education */}
          {education ? (
            <div className="mb-5">
              <div className="inline-flex items-center gap-2 text-gray-700">
                <BookOpen className="w-4 h-4 text-blue-600" />
                <span className="font-medium">Education</span>
              </div>
              <p className="text-gray-600 mt-1">{education}</p>
            </div>
          ) : null}

          {/* Actions */}
          <div className="flex flex-wrap gap-3">
            {scholarUrl ? (
              <a href={scholarUrl} target="_blank" rel="noreferrer">
                <Button className="px-4">
                  <GraduationCap className="mr-2 h-4 w-4" />
                  Google Scholar
                </Button>
              </a>
            ) : null}
            {cvUrl ? (
              <a href={cvUrl} target="_blank" rel="noreferrer">
                <Button variant="outline" className="bg-transparent">
                  <FileText className="mr-2 h-4 w-4" />
                  CV
                </Button>
              </a>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  )
}

export default PrincipalInvestigatorCard
