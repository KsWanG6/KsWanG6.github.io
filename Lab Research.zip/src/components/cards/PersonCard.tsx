/**
 * PersonCard component
 * Displays a lab member with avatar, role, optional contact and education info. Supports row/column layout.
 */
import React from 'react'
import { Mail, Phone } from 'lucide-react'

/** Props for PersonCard */
export interface PersonCardProps {
  /** Person name */
  name: string
  /** Role or position */
  role: string
  /** Avatar image URL */
  avatar: string
  /** Optional additional details (e.g., short bio or research topic) */
  details?: string
  /** Optional mobile phone number */
  mobile?: string
  /** Optional email address */
  email?: string
  /** Optional education text or array */
  education?: string | string[]
  /** Layout 'row' or 'column' */
  layout?: 'row' | 'column'
}

/**
 * PersonCard
 * A profile card that supports row/column layouts and optional contact/education sections.
 */
const PersonCard: React.FC<PersonCardProps> = ({
  name,
  role,
  avatar,
  details,
  mobile,
  email,
  education,
  layout = 'row',
}) => {
  const isRow = layout === 'row'

  /** Build tel/mailto links only if values exist */
  const telHref = mobile ? `tel:${mobile.replace(/[^+\d]/g, '')}` : undefined
  const mailHref = email ? `mailto:${email}` : undefined

  /** Normalize education to single string for display */
  const educationText =
    Array.isArray(education) ? education.filter(Boolean).join(' • ') : education

  return (
    <div className="rounded-xl bg-gray-50 p-5 border border-gray-100 hover:border-gray-200 transition-colors">
      <div className={isRow ? 'flex items-start gap-4' : 'flex flex-col items-center text-center'}>
        <img
          src={avatar}
          alt={name}
          className={isRow ? 'w-20 h-20 rounded-lg object-cover' : 'w-16 h-16 rounded-lg object-cover mb-3'}
        />
        <div className={isRow ? '' : ''}>
          <h4 className="text-lg font-semibold text-gray-800">{name}</h4>
          <p className="text-gray-600 text-sm">{role}</p>

          {details ? <p className="text-gray-700 text-sm mt-2">{details}</p> : null}

          {educationText ? (
            <p className="text-gray-600 text-sm mt-2">
              <span className="font-medium text-gray-700">Education:</span> {educationText}
            </p>
          ) : null}

          {(mobile || email) ? (
            <div className="flex flex-wrap gap-x-5 gap-y-2 text-sm mt-3">
              {mobile ? (
                <a href={telHref} className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-700">
                  <Phone className="w-4 h-4" />
                  <span>{mobile}</span>
                </a>
              ) : null}
              {email ? (
                <a href={mailHref} className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-700">
                  <Mail className="w-4 h-4" />
                  <span>{email}</span>
                </a>
              ) : null}
            </div>
          ) : null}
        </div>
      </div>
    </div>
  )
}

export default PersonCard
