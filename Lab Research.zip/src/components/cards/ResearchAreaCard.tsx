/**
 * ResearchAreaCard component
 * Displays a research area with image, title, and brief description.
 */
import React from 'react'

/** Props for ResearchAreaCard */
export interface ResearchAreaCardProps {
  /** Card title */
  title: string
  /** Description text */
  description: string
  /** Image URL */
  image: string
  /** Optional accent color border (Tailwind color classes) */
  accentColor?: string
}

/**
 * ResearchAreaCard
 * A hover-elevated card for research areas with subtle border accent.
 */
const ResearchAreaCard: React.FC<ResearchAreaCardProps> = ({
  title,
  description,
  image,
  accentColor = 'border-blue-200',
}) => {
  return (
    <div
      className={`group rounded-xl border ${accentColor} bg-white/80 backdrop-blur-sm shadow-sm hover:shadow-lg transition-shadow duration-300`}
    >
      <div className="p-4">
        <div className="rounded-lg overflow-hidden">
          <img src={image} alt={title} className="w-full h-40 object-cover" />
        </div>
        <h3 className="mt-4 text-lg font-semibold text-gray-800">{title}</h3>
        <p className="mt-2 text-gray-600 text-sm leading-relaxed">{description}</p>
      </div>
    </div>
  )
}

export default ResearchAreaCard
