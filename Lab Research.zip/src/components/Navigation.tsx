/**
 * Compact glassmorphism navigation bar with responsive behavior and active glow underline
 * - Mobile-first: single row, no horizontal scroll or scrollbar; sizes shrink to fit
 * - Active indicator: thin glowing underline that transitions under the active tab
 * - Fix: prevent initial flicker-left by delaying indicator until measurement is ready and re-measuring on fonts/load/resize.
 */

import React, { useEffect, useLayoutEffect, useRef, useState } from 'react'

/**
 * Props for Navigation
 * - onNavigate: callback to switch section
 * - currentSection: current active section id
 */
interface NavigationProps {
  /** Callback to switch section */
  onNavigate: (section: string) => void
  /** Active section id */
  currentSection: string
}

/** Navigation item shape */
interface NavItem {
  /** Section id for routing inside the page */
  id: string
  /** Display label */
  label: string
}

/** Position and size for the active underline indicator */
interface IndicatorState {
  /** Left offset relative to the scrolling container */
  left: number
  /** Width equal to the active button width */
  width: number
}

/**
 * Navigation
 * Renders a compact glassmorphism navbar with responsive layout and an active glowing underline.
 * Mobile: single row, no horizontal scroll; sizes are tuned to fit 320px devices.
 * Fixes the "underline jumps to far-left on refresh" by:
 * - Hiding indicator until a valid measurement is available
 * - Re-measuring after fonts/load/resize and on the next animation frame
 */
const Navigation: React.FC<NavigationProps> = ({ onNavigate, currentSection }) => {
  /** Navigation items */
  const navItems: NavItem[] = [
    { id: 'home', label: 'HOME' },
    { id: 'people', label: 'GROUP' },
    { id: 'research', label: 'RESEARCH' },
    { id: 'publications', label: 'PUBLICATIONS' },
    { id: 'contact', label: 'CONTACT' },
  ]

  /** Refs for measurement: container and each button */
  const containerRef = useRef<HTMLDivElement | null>(null)
  const itemRefs = useRef<Record<string, HTMLButtonElement | null>>({})

  /** Active indicator position and size */
  const [indicator, setIndicator] = useState<IndicatorState>({ left: 0, width: 0 })
  /** Whether we have a valid measurement; used to avoid initial flicker-left */
  const [ready, setReady] = useState(false)

  /**
   * Compute and update the underline indicator position/size
   * - Measure active button bounding rect against the container
   * - Avoid updating when not measurable; mark ready when width > 0
   */
  const updateIndicator = () => {
    const container = containerRef.current
    const activeBtn = itemRefs.current[currentSection]
    if (!container || !activeBtn) return

    const cRect = container.getBoundingClientRect()
    const aRect = activeBtn.getBoundingClientRect()
    const left = aRect.left - cRect.left + container.scrollLeft
    const width = aRect.width

    if (width > 0) {
      setIndicator({ left, width })
      setReady(true)
    }
  }

  /**
   * Recalculate indicator when currentSection changes
   * - Use layout effect for immediate measurement after DOM updates
   * - Also schedule a next-frame re-measure to handle font/layout settling
   */
  useLayoutEffect(() => {
    updateIndicator()
    // Keep for accessibility parity; no horizontal scroll, but harmless.
    itemRefs.current[currentSection]?.scrollIntoView({
      behavior: 'auto',
      inline: 'center',
      block: 'nearest',
    })

    const raf = requestAnimationFrame(() => updateIndicator())
    return () => cancelAnimationFrame(raf)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentSection])

  /**
   * Bind resize and load/font events to keep indicator accurate
   * - window resize
   * - window load
   * - document.fonts.ready (if supported)
   * - ResizeObserver on container (handles width changes from breakpoints)
   */
  useEffect(() => {
    const onResize = () => updateIndicator()
    const onLoad = () => updateIndicator()

    window.addEventListener('resize', onResize)
    window.addEventListener('load', onLoad)

    // Fonts ready (some browsers)
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const fontsReady: Promise<unknown> | undefined = (document as any).fonts?.ready
    let cancelled = false
    if (fontsReady) {
      fontsReady.then(() => {
        if (!cancelled) updateIndicator()
      })
    }

    // ResizeObserver for container
    let ro: ResizeObserver | undefined
    if (containerRef.current && typeof ResizeObserver !== 'undefined') {
      ro = new ResizeObserver(() => updateIndicator())
      ro.observe(containerRef.current)
    }

    // Initial async re-measure in case of late layout
    const raf = requestAnimationFrame(() => updateIndicator())

    return () => {
      window.removeEventListener('resize', onResize)
      window.removeEventListener('load', onLoad)
      cancelled = true
      if (ro) ro.disconnect()
      cancelAnimationFrame(raf)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <nav
      className="fixed top-4 sm:top-5 md:top-6 left-1/2 -translate-x-1/2 z-50 px-2 sm:px-0"
      role="navigation"
      aria-label="Primary"
    >
      {/* Glassmorphism capsule: mobile takes near full width, no horizontal scroll */}
      <div
        className="relative backdrop-blur-xl bg-white/20 rounded-full shadow-xl border border-white/40 w-[calc(100vw-1.5rem)] sm:w-auto max-w={[980px] as unknown as string]"
        style={{
          backdropFilter: 'blur(16px) saturate(170%)',
          WebkitBackdropFilter: 'blur(16px) saturate(170%)',
          boxShadow: '0 8px 28px rgba(0,0,0,0.10), inset 0 1px 0 rgba(255,255,255,0.20)',
        }}
      >
        {/* Single-row, no-scroll container; compact base sizes to fit 320px screens */}
        <div className="relative">
          <div
            ref={containerRef}
            className="flex items-center justify-center gap-1 sm:gap-4 md:gap-5 px-2 py-1.5 sm:px-5 sm:py-2 md:px-6 md:py-2.5 overflow-x-hidden"
          >
            {navItems.map((item) => (
              <button
                key={item.id}
                ref={(el) => {
                  itemRefs.current[item.id] = el
                }}
                onClick={() => onNavigate(item.id)}
                className={`px-2 py-1 text-[10px] sm:px-4 sm:py-2 sm:text-sm md:px-5 md:py-2 md:text-base font-medium tracking-wide transition-all duration-300 rounded-full font-lato whitespace-nowrap ${
                  currentSection === item.id
                    ? 'bg-white/30 text-gray-900 shadow-md backdrop-blur-sm'
                    : 'text-gray-800 hover:bg-white/20 hover:text-gray-900 hover:backdrop-blur-sm'
                }`}
                aria-current={currentSection === item.id ? 'page' : undefined}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Active glowing underline (progress-like) */}
          <div aria-hidden="true" className="pointer-events-none absolute left-0 right-0 bottom-1">
            <div
              style={{
                width: `${indicator.width}px`,
                transform: `translateX(${indicator.left}px)`,
              }}
              className={`h-[2px] md:h-[3px] rounded-full bg-cyan-400/80 transition-[transform,width,opacity] duration-300 ease-out shadow-[0_0_8px_rgba(34,211,238,0.65)] ${
                ready ? 'opacity-100' : 'opacity-0'
              }`}
            />
          </div>
        </div>
      </div>
    </nav>
  )
}

export default Navigation
