/**
 * PublicationsList component
 * Renders publications grouped by year with a "Load more" control to reveal older years incrementally.
 */
import React, { useMemo, useState } from 'react'
import { Button } from '../ui/button'
import ChemText from '../typography/ChemText'

/** Interface for a single publication item */
export interface Publication {
  /** Year of publication */
  year: number
  /** Paper title */
  title: string
  /** Journal metadata (journal name, volume, pages, notes) */
  journalMeta: string
  /** Authors string */
  authors: string
}

/** Props for PublicationsList */
export interface PublicationsListProps {
  /** Flat list of publications with year; the component will group by year descending */
  items: Publication[]
  /** Initial number of years to show (from latest) */
  initialYearsToShow?: number
  /** Number of years to reveal per "Load more" click */
  loadMoreYears?: number
}

/**
 * PublicationsList
 * Groups publications by year and progressively reveals older years via Load more.
 * Also formats chemical formulas in titles and journal metadata using ChemText.
 */
const PublicationsList: React.FC<PublicationsListProps> = ({
  items,
  initialYearsToShow = 5,
  loadMoreYears = 3,
}) => {
  /** Group publications by year (descending) */
  const { yearsDesc, byYear } = useMemo(() => {
    const map = new Map<number, Publication[]>()

    for (const pub of items) {
      if (!map.has(pub.year)) map.set(pub.year, [])
      map.get(pub.year)!.push(pub)
    }

    // Sort items inside each year if needed (keep input order otherwise)
    for (const [year, pubs] of map) {
      map.set(
        year,
        pubs.slice() // stable copy
      )
    }

    const years = Array.from(map.keys()).sort((a, b) => b - a)
    return { yearsDesc: years, byYear: map }
  }, [items])

  /** How many year-groups are currently visible */
  const [visibleYearCount, setVisibleYearCount] = useState(
    Math.min(initialYearsToShow, yearsDesc.length)
  )

  /** Whether there are still older years to reveal */
  const canLoadMore = visibleYearCount < yearsDesc.length

  /** Reveal more year-groups */
  const handleLoadMore = () => {
    setVisibleYearCount((c) => Math.min(c + loadMoreYears, yearsDesc.length))
  }

  const visibleYears = yearsDesc.slice(0, visibleYearCount)

  return (
    <div className="space-y-10">
      {visibleYears.map((year) => (
        <div key={year}>
          <h3 className="text-xl font-semibold text-gray-800 mb-3">{year}</h3>
          <div className="space-y-4">
            {byYear.get(year)!.map((p, idx) => (
              <div key={`${year}-${idx}`} className="rounded-lg bg-gray-50 p-4 border border-gray-100">
                <h4 className="font-medium text-gray-800 mb-2">
                  <ChemText text={p.title} />
                </h4>
                <p className="text-sm text-gray-600 mb-1">
                  <ChemText text={p.journalMeta} />
                </p>
                <p className="text-sm text-gray-700">{p.authors}</p>
              </div>
            ))}
          </div>
        </div>
      ))}

      {canLoadMore ? (
        <div className="flex justify-center">
          <Button onClick={handleLoadMore} aria-label="Load more publications">
            Load more
          </Button>
        </div>
      ) : null}
    </div>
  )
}

export default PublicationsList
