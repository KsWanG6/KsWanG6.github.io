/**
 * PublicationItem component
 * Displays a single publication entry with journal and authors.
 */
import React from 'react'

/** Props for PublicationItem */
export interface PublicationItemProps {
  /** Paper title */
  title: string
  /** Journal and meta like volume/pages/year */
  journalMeta: string
  /** Authors string */
  authors: string
}

/**
 * PublicationItem
 * Presents publication info in a clean box with subtle emphasis on the title.
 */
const PublicationItem: React.FC<PublicationItemProps> = ({ title, journalMeta, authors }) => {
  return (
    <div className="rounded-lg bg-gray-50 p-4 border border-gray-100">
      <h4 className="font-medium text-gray-800 mb-2">{title}</h4>
      <p className="text-sm text-gray-600 mb-1">{journalMeta}</p>
      <p className="text-sm text-gray-700">{authors}</p>
    </div>
  )
}

export default PublicationItem
