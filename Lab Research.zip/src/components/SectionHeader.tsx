/**
 * SectionHeader component
 * Provides a consistent section heading with an accent and optional description.
 */
import React from 'react'

/** Props for SectionHeader: title, optional subtitle, and accent color */
export interface SectionHeaderProps {
  /** Main title of the section */
  title: string
  /** Optional subtitle under the title */
  subtitle?: string
  /** Tailwind color class for the accent bar (e.g., 'from-blue-500 to-cyan-400') */
  accentGradient?: string
  /** Additional className for wrapper customization */
  className?: string
}

/**
 * SectionHeader
 * Renders a title with a gradient accent bar and optional subtitle.
 */
const SectionHeader: React.FC<SectionHeaderProps> = ({
  title,
  subtitle,
  accentGradient = 'from-blue-600 to-cyan-500',
  className = '',
}) => {
  return (
    <div className={`mb-8 ${className}`}>
      <div className="flex items-center gap-3">
        <span
          className={`inline-block h-6 w-1 rounded-full bg-gradient-to-b ${accentGradient}`}
          aria-hidden="true"
        />
        <h2 className="text-3xl font-bold text-gray-800">{title}</h2>
      </div>
      {subtitle ? (
        <p className="mt-3 text-gray-600 leading-relaxed">{subtitle}</p>
      ) : null}
    </div>
  )
}

export default SectionHeader
