/**
 * Header component for the KSWang Lab website
 * Clean and professional header with academic styling
 */
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-white py-8">
      <div className="container mx-auto px-4">
        <div className="text-left">

          <p className="text-lg text-gray-600">Department of Biomedical Engineering</p>
          <p className="text-sm text-gray-500 mt-1">University Research Center</p>
        </div>
      </div>
    </header>
  );
};

export default Header;
